IRDS OFFICIAL WEBSITE STARTER
============================

Files:
- index.html: page content
- style.css: responsive styling
- script.js: mobile menu and footer year
- assets/irds-mark.svg: editable project emblem

PRE-PUBLISH CHECKLIST
1. Replace the generic Roblox link in index.html with your actual game URL.
2. Replace the generic Discord link with your actual server invite.
3. Confirm the listed route stops and feature descriptions with the project team.
4. Publish with GitHub Pages:
   - Create/sign in to GitHub and make a new public repository.
   - Upload all files and folders in this package (keep index.html at repository root).
   - Open repository Settings > Pages.
   - Choose Deploy from a branch, select main and /(root), then Save.
   - Wait for the Pages URL to appear in Settings > Pages.

This is a website starter, not a live hosted website. No official URL is created until you publish it.
